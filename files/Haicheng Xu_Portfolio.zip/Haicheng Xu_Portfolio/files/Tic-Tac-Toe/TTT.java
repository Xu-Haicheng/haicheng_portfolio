public class TTT

{

    private static String[][] board;

    private static String currentPlayerMark = " O ";

    

    public static void printBoard() {

        

        for (int r = 0; r < board.length; r++) {

            for (int c = 0; c < board.length; c++) {

                System.out.print(board[r][c]);

            }

            System.out.println();

        }

    }

    

    public static boolean isBoardFull() {

        boolean isFull = true;

        for (int i = 0; i < board.length; i++) {

            for (int j = 0; j < board.length; j++) {

                if (board[i][j] == " - ") {

                    isFull = false;

                }

            }

        }

        return isFull;

    }

    

    public static String[][] initializeBoard(int n) {

        board = new String[n][n];

        for (int row = 0; row < board.length; row++) {

            for (int column = 0; column < board.length; column++) {

                if (row == 0) {

                    if (column < 10) {

                        board[row][column] = Integer.toString(column) + "  ";

                    }

                    else {

                        board[row][column] = Integer.toString(column) + " ";

                    }

                }

                else if (column == 0) {

                    if (row < 10) {

                        board[row][column] = Integer.toString(row) + " ";

                    }

                    else {

                        board[row][column] = Integer.toString(row);

                    }

                }

                else {

                    board[row][column] = " - ";

                }

            }

        }

        return board;

    }

    

    public static void changePlayer() {

        if (currentPlayerMark == " X ") {

            currentPlayerMark = " O ";

            System.out.println("It is Player O's turn.");

        }

        else {

            currentPlayerMark = " X ";

            System.out.println("It is Player X's turn.");

        }

    }

    

    public static boolean placeMark(int row, int col) {

        if ((row >= 1) && (row < board.length)) {

            if ((col >= 1) && (col < board.length)) {

                if (board[row][col] == " - ") {

                    board[row][col] = currentPlayerMark;

                    return true;

                }

            }

        }

        return false;

    }

    

    public static boolean checkForWinner() {

        int match = 0;

        //columns

        for (int i = 1; i < board.length; i++) {

            match = 0;

            for (int j = 1; j < board.length - 1; j++) {

                if (board[j][i].equals(" X ")|| board[j][i].equals(" O ")) {

                    if (board[j][i].equals(board[j+1][i])) {

                        match++;

                    }

                }

            }

            if (match == board.length - 2) {

                return true;

            }

        }

        //rows

        for (int i = 1; i < board.length; i++) {

            match = 0;

            for (int j = 1; j < board.length - 1; j++) {

                if (board[i][j].equals(" X ")|| board[i][j].equals(" O ")) {

                    if (board[i][j].equals(board[i][j+1])) {

                        match++;

                    }

                }

            }

            if (match == board.length - 2) {

                return true;

            }

        }

        match = 0;

        //first diagonal

        int i;

        for (int j = 1; j < board.length - 1; j++) {

            i = j;

            if (board[j][i].equals(" X ") || board[j][i].equals(" O ")) {

                if (board[j][i].equals(board[j+1][i+1])) {

                    match++;

                }

            }

            if (match == board.length - 2) {

                return true;

            }

        }

        //second diagonal

        int j = 0;

        match = 0;

        for (int k = board.length - 1; k > 1; k--) {

            if (board[k][j].equals(" X ") || board[k][j].equals(" O ")) {

                if (board[k][j].equals(board[k-1][j+1])) {

                    match++;

                }

            }

            if (match == board.length - 2) {

                return true;

            }

            j++;

        }

        return false;

    }

    

    public static void main() {

        System.out.println("Tic-Tac-Toe 2.0");

        System.out.println("Please enter board size.");

        String size = Play.getString();

        initializeBoard(Integer.parseInt(size)+1);

        int row, col;

        

        boolean menu = true;

        while(menu) {

            System.out.println("Options: ");

            System.out.println(" 1) Print the game board");

            System.out.println(" 2) Single Player");

            System.out.println(" 3) 2 Players");

            System.out.println(" 4) Exit out of game");

            System.out.println();

            System.out.print("Choose 1, 2, 3, or 4: ");

            String choice = Play.getString();

            

            if (choice.equals("1")) {

                printBoard();

            }

            

            else if (choice.equals("2")) {

                playerVersusComputer();

              

            }

            

            else if (choice.equals("3")) {

                playerVersusPlayer();

            }

            

            else if (choice.equals("4")) {

                menu = false;

                System.out.println("Exiting out of game.");

            }

        }

    }

    

    public static void playerVersusPlayer() {

        while(!checkForWinner() && !isBoardFull()){

            printBoard();

            changePlayer();

            boolean mark = false;

            //user input

            while(!mark) {

                System.out.print("Enter row: ");

                String rowNum = Play.getString();

                int rowNumResult = Integer.parseInt(rowNum);

                int x = rowNumResult;

                

                System.out.print("Enter column: ");

                String colNum = Play.getString();

                int colNumResult = Integer.parseInt(colNum);

                int y = colNumResult;

                mark = placeMark(x,y);

            }

        }

        

        if (isBoardFull() && !checkForWinner()) {

            System.out.println("tie!");

        }

        else {

            System.out.println("Here is the current game board: ");

            printBoard();

            

            System.out.println(currentPlayerMark + " wins! would you like to play again? Choose from the options below.");

        }

    }

    

    public static void playerVersusComputer() {

        System.out.println("The player is X and the computer is O.");

        while(!checkForWinner() && !isBoardFull()){

            printBoard();

            changePlayer();

            boolean mark = false;

            //user input

            if(currentPlayerMark.equals(" X ")) {

                while(!mark) {

                    System.out.print("Enter row: ");

                    String rowNum = Play.getString();

                    int rowNumResult = Integer.parseInt(rowNum);

                    int x = rowNumResult;

                    

                    System.out.print("Enter column: ");

                    String colNum = Play.getString();

                    int colNumResult = Integer.parseInt(colNum);

                    int y = colNumResult;

                    mark = placeMark(x,y);

                }

            }

            else {

                    computerMove();

            }

        }

        

        if (isBoardFull() && !checkForWinner()) {

            System.out.println("tie!");

        }

        else {

            System.out.println("Here is the current game board: ");

            printBoard();

            

            System.out.println(currentPlayerMark + " wins! would you like to play again?");

        }

    }

    

    public static void computerMove() {

        int x = (int) ((Math.random() * (board.length - 1)) + 1);

        int y = (int) ((Math.random() * (board.length - 1)) + 1);

        System.out.println(x);

        System.out.println(y);

        int countX = 0;

        int countO = 0;

        

        //columns

        for (int i = 1; i < board.length; i++) {

            countX = 0;

            countO = 0;

            for (int j = 1; j < board.length; j++) {

                if (board[j][i].equals(" X ")) {

                    countX++;

                }

                else if (board[j][i].equals(" O ")) {

                    countO++;

                }

            }

            if ((countX == board.length - 2) || (countO == board.length - 2)) {

                for (int row = 1; row < board.length; row++) {

                    if (board[row][i].equals(" - ")) {

                        placeMark(row, i);

                        return;

                    }

                }

            }

        }

        countX = 0;

        countO = 0;

        //rows

        for (int i = 1; i < board.length; i++) {

            countX = 0;

            countO = 0;

            for (int j = 1; j < board.length; j++) {

                if (board[i][j].equals(" X ")) {

                    countX++;

                }

                else if (board[i][j].equals(" O ")) {

                    countO++;

                }

            }

            if ((countX == board.length - 2) || (countO == board.length - 2)) {

                for (int col = 1; col < board.length; col++) {

                    if (board[i][col].equals(" - ")) {

                        placeMark(i, col);

                        return;

                    }

                }

            }

        }

        //first diagonal

        countX = 0;

        countO = 0;

        int i;

        for (int j = 1; j < board.length - 1; j++) {

            i = j;

            if (board[j][i].equals(" X ")) {

                countX++;

            }

            if (board[j][i].equals(" O ")) {

                countO++;

            }

            if ((countX == board.length - 2) || (countO == board.length - 2)) {

                int a;

                for (int b = 1; b < board.length; b++) {

                    a = b;

                    if (board[b][a].equals(" - ")) {

                        placeMark(b, a);

                        return;

                    }

                }

            }

        }

        //second diagonal

        countX = 0;

        countO = 0;

        int j = 1;

        for (int k = board.length - 1; k > 1; k--) {

            if (board[k][j].equals(" X ")) {

                countX++;

            }

            if (board[k][j].equals(" O ")) {

                countO++;

            }

            if ((countX == board.length - 2) || (countO == board.length - 2)) {

                int m = 1;

                for (int n = board.length - 1; n > 1; n--) {

                    if (board[n][m].equals(" - ")) {

                        placeMark(n, m);

                        return;

                    }

                    m++;

                }

            }

            j++;

        }

        countX = 0;

        countO = 0;

        placeMark(x, y);

    }

}


